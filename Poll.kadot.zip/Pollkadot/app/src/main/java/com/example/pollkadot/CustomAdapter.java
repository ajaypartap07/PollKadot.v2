package com.example.pollkadot;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pollkadot.R;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private Context context;
    private Activity activity;
    private ArrayList poll_id, poll_ques, poll_opt1, poll_opt2, poll_opt3, poll_opt4;

    CustomAdapter(Activity activity, Context context, ArrayList poll_id, ArrayList poll_ques, ArrayList poll_opt1, ArrayList poll_opt2,
                  ArrayList poll_opt3, ArrayList poll_opt4){
        this.activity = activity;
        this.context = context;
        this.poll_id = poll_id;
        this.poll_ques = poll_ques;
        this.poll_opt1 = poll_opt1;
        this.poll_opt2 = poll_opt2;
        this.poll_opt3 = poll_opt3;
        this.poll_opt4 = poll_opt4;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.poll_activity, parent, false);
        return new MyViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        //holder.book_id_txt.setText(String.valueOf(book_id.get(position)));
        holder.poll_ques_txt.setText(String.valueOf(poll_ques.get(position)));
        holder.poll_opt1_txt.setText(String.valueOf(poll_opt1.get(position)));
        holder.poll_opt2_txt.setText(String.valueOf(poll_opt2.get(position)));
        holder.poll_opt3_txt.setText(String.valueOf(poll_opt3.get(position)));
        holder.poll_opt4_txt.setText(String.valueOf(poll_opt4.get(position)));
        //Recyclerview onClickListener

        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Intent intent = new Intent(context, UpdateActivity.class);
                intent.putExtra("id", String.valueOf(poll_id.get(position)));
                intent.putExtra("Poll Question", String.valueOf(poll_ques.get(position)));
                intent.putExtra("Poll Option 1", String.valueOf(poll_opt1.get(position)));
                intent.putExtra("Poll Option 2", String.valueOf(poll_opt2.get(position)));
                intent.putExtra("Poll Option 3", String.valueOf(poll_opt3.get(position)));
                intent.putExtra("Poll Option 4", String.valueOf(poll_opt4.get(position)));
                activity.startActivityForResult(intent, 1);*/
            }
        });


    }

    @Override
    public int getItemCount() {
        return poll_id.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView poll_id_txt, poll_ques_txt, poll_opt1_txt, poll_opt2_txt, poll_opt3_txt, poll_opt4_txt;
        LinearLayout mainLayout;

        MyViewHolder(@NonNull View itemView) {
            super(itemView);
           //poll_id_txt = itemView.findViewById(R.id.poll_id_txt);
            poll_ques_txt = itemView.findViewById(R.id.pollQ_textview);
            poll_opt1_txt = itemView.findViewById(R.id.option1_textview);
            poll_opt2_txt = itemView.findViewById(R.id.option2_textview);
            poll_opt3_txt = itemView.findViewById(R.id.option3_textview);
            poll_opt4_txt = itemView.findViewById(R.id.option4_textview);
            //mainLayout = itemView.findViewById(R.id.);
            //Animate Recyclerview
            //Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
            //mainLayout.setAnimation(translate_anim);
        }

    }

}
