package com.example.pollkadotv2;

public class UserInformation {

    public String name;
    public String address;

    public UserInformation(String name, String address) {
        this.name = name;
        this.address = address;
    }
}
